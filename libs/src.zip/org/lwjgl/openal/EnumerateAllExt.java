/*
 * Copyright LWJGL. All rights reserved.
 * License terms: http://lwjgl.org/license.php
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openal;

/** bindings to ALC_ENUMERATE_ALL_EXT extension. */
public final class EnumerateAllExt {

	/** ENUMERATE_ALL_EXT tokens. */
	public static final int
		ALC_DEFAULT_ALL_DEVICES_SPECIFIER = 0x1012,
		ALC_ALL_DEVICES_SPECIFIER         = 0x1013;

	private EnumerateAllExt() {}

}